function load() {
    let _inner = document.getElementById('word').value
    let _result = document.getElementById('result')
    console.log(_inner)
    // document.getElementsByTagName('h6')[0].innerHTML = _inner
    fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${_inner}`)
        .then(function (response) {
            if (!response.ok) {
                _result.innerHTML = `<h3 class="error">Couldn't Find The Word</h3>`;
            }
            response.json().then(function (data) {
                    _result.innerHTML = `
                        <h2 class=" col-6 d-flex align-items-center justify-content-start">${data[0].word}</h2>
                        <h2 class="col-6 d-flex justify-content-end align-items-center">
                        <span class="audio material-symbols-outlined "  onclick="audio()">
                            volume_up
                        </span>
                        </h2>
                        <h6 class="col-6">${data[0].meanings[0].partOfSpeech}</h6>
                        <h6 class="col-6">${data[0].phonetics[0].text}</h6>
                        <h5 class="col-12">${data[0].meanings[0].definitions[0].definition}</h5>
                        <h4 class="col-12">${ data[0].meanings[0].definitions[0].example}</h4>
                `

                    function audio(data) {
                        let _audio = document.getElementsByClassName('audio')[0]
                        _audio.setAttribute("src", `https:${data[0].phonetics[0].audio}`)
                        _audio.play()
                    }
                })
                .catch(() => {

                });
        })
}